import { configureStore, createSlice } from '@reduxjs/toolkit';

// ─── AUTH SLICE ─────────────────────────────────────────────
const authSlice = createSlice({
  name: 'auth',
  initialState: { user: null, token: null, loading: false },
  reducers: {
    setUser: (state, action) => { state.user = action.payload; },
    setToken: (state, action) => { state.token = action.payload; },
    setLoading: (state, action) => { state.loading = action.payload; },
    logout: (state) => { state.user = null; state.token = null; },
  },
});

// ─── DASHBOARD SLICE ─────────────────────────────────────────
const dashboardSlice = createSlice({
  name: 'dashboard',
  initialState: { data: null, loading: false, error: null },
  reducers: {
    setDashboard: (state, action) => { state.data = action.payload; state.loading = false; },
    setLoading: (state, action) => { state.loading = action.payload; },
    setError: (state, action) => { state.error = action.payload; state.loading = false; },
  },
});

// ─── PRODUCTS SLICE ──────────────────────────────────────────
const productsSlice = createSlice({
  name: 'products',
  initialState: { list: [], loading: false },
  reducers: {
    setProducts: (state, action) => { state.list = action.payload; state.loading = false; },
    setLoading: (state, action) => { state.loading = action.payload; },
    addProduct: (state, action) => { state.list.unshift(action.payload); },
    removeProduct: (state, action) => {
      state.list = state.list.filter(p => p.id !== action.payload);
    },
  },
});

// ─── CUSTOMERS SLICE ─────────────────────────────────────────
const customersSlice = createSlice({
  name: 'customers',
  initialState: { list: [], loading: false },
  reducers: {
    setCustomers: (state, action) => { state.list = action.payload; state.loading = false; },
    setLoading: (state, action) => { state.loading = action.payload; },
    addCustomer: (state, action) => { state.list.unshift(action.payload); },
  },
});

// ─── CART SLICE (Billing) ────────────────────────────────────
const cartSlice = createSlice({
  name: 'cart',
  initialState: { items: [], customer: null },
  reducers: {
    addToCart: (state, action) => {
      const existing = state.items.find(i => i.product_id === action.payload.product_id);
      if (existing) {
        existing.quantity += action.payload.quantity;
      } else {
        state.items.push(action.payload);
      }
    },
    removeFromCart: (state, action) => {
      state.items = state.items.filter(i => i.product_id !== action.payload);
    },
    updateQuantity: (state, action) => {
      const item = state.items.find(i => i.product_id === action.payload.id);
      if (item) item.quantity = action.payload.quantity;
    },
    setCustomer: (state, action) => { state.customer = action.payload; },
    clearCart: (state) => { state.items = []; state.customer = null; },
  },
});

export const authActions = authSlice.actions;
export const dashboardActions = dashboardSlice.actions;
export const productsActions = productsSlice.actions;
export const customersActions = customersSlice.actions;
export const cartActions = cartSlice.actions;

export const store = configureStore({
  reducer: {
    auth: authSlice.reducer,
    dashboard: dashboardSlice.reducer,
    products: productsSlice.reducer,
    customers: customersSlice.reducer,
    cart: cartSlice.reducer,
  },
});
