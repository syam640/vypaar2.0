import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

const BASE_URL = 'https://your-backend.onrender.com'; // Update after deploy

const api = axios.create({
  baseURL: BASE_URL,
  timeout: 15000,
  headers: { 'Content-Type': 'application/json' },
});

// Auto-inject auth token
api.interceptors.request.use(async (config) => {
  const token = await AsyncStorage.getItem('auth_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// ─── BILLING ────────────────────────────────────────────────
export const createBill = (data) => api.post('/bill/create', data);
export const getBillHistory = (userId) => api.get(`/bill/history/${userId}`);

// ─── DASHBOARD ──────────────────────────────────────────────
export const getDashboard = (userId) => api.get(`/dashboard/${userId}`);

// ─── PRODUCTS ───────────────────────────────────────────────
export const getProducts = (userId) => api.get(`/products/${userId}`);
export const addProduct = (data) => api.post('/products/add', data);
export const updateProduct = (id, data) => api.put(`/products/${id}`, data);
export const deleteProduct = (id) => api.delete(`/products/${id}`);
export const getLowStock = (userId) => api.get(`/products/${userId}/low-stock`);

// ─── CUSTOMERS ──────────────────────────────────────────────
export const getCustomers = (userId) => api.get(`/customers/${userId}`);
export const addCustomer = (data) => api.post('/customers/add', data);
export const getSegments = (userId) => api.get(`/customers/${userId}/segments`);

// ─── ML ─────────────────────────────────────────────────────
export const getDemandForecast = (userId) => api.get(`/ml/predict-demand/${userId}`);
export const getSegmentation = (userId) => api.get(`/ml/customer-segmentation/${userId}`);
export const getAnomalies = (userId) => api.get(`/ml/anomaly/${userId}`);

// ─── INSIGHTS ───────────────────────────────────────────────
export const generateInsights = (userId, language = 'en') =>
  api.post('/insights/generate', { user_id: userId, language });
export const getInsights = (userId) => api.get(`/insights/${userId}`);

// ─── OCR ────────────────────────────────────────────────────
export const scanBill = (formData) =>
  api.post('/ocr/scan-bill', formData, { headers: { 'Content-Type': 'multipart/form-data' } });

export default api;
