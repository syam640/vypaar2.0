import React, { useEffect, useState } from 'react';
import {
  View, Text, FlatList, StyleSheet, TouchableOpacity, Modal,
  TextInput, Alert, ActivityIndicator, RefreshControl
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getCustomers, addCustomer, getSegmentation } from '../services/api';

const SEGMENT_CONFIG = {
  loyal: { color: '#27ae60', bg: '#eafaf1', icon: '🌟', label: 'Loyal' },
  at_risk: { color: '#e74c3c', bg: '#fdeaea', icon: '⚠️', label: 'At Risk' },
  new: { color: '#3498db', bg: '#eaf4fb', icon: '🆕', label: 'New' },
};

export default function CustomersScreen() {
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [form, setForm] = useState({ name: '', phone: '', email: '' });
  const [submitting, setSubmitting] = useState(false);
  const [filterSegment, setFilterSegment] = useState('all');
  const [runningML, setRunningML] = useState(false);

  const fetchCustomers = async () => {
    const uid = await AsyncStorage.getItem('user_id');
    const res = await getCustomers(uid);
    setCustomers(res.data.customers || []);
    setLoading(false);
    setRefreshing(false);
  };

  useEffect(() => { fetchCustomers(); }, []);

  const handleAddCustomer = async () => {
    if (!form.name) return Alert.alert('Error', 'Name is required');
    setSubmitting(true);
    const uid = await AsyncStorage.getItem('user_id');
    try {
      await addCustomer({ ...form, user_id: uid });
      setModalVisible(false);
      setForm({ name: '', phone: '', email: '' });
      fetchCustomers();
    } catch (e) {
      Alert.alert('Error', 'Failed to add customer');
    } finally {
      setSubmitting(false);
    }
  };

  const runSegmentation = async () => {
    setRunningML(true);
    const uid = await AsyncStorage.getItem('user_id');
    try {
      await getSegmentation(uid);
      Alert.alert('✅ Done', 'Customer segments updated with ML!');
      fetchCustomers();
    } catch (e) {
      Alert.alert('Error', e.response?.data?.detail || 'Segmentation failed');
    } finally {
      setRunningML(false);
    }
  };

  const displayed = filterSegment === 'all' ? customers :
    customers.filter(c => c.segment === filterSegment);

  if (loading) return <View style={styles.center}><ActivityIndicator color="#6C63FF" size="large" /></View>;

  return (
    <View style={styles.container}>
      {/* ML Run Button */}
      <TouchableOpacity style={styles.mlBtn} onPress={runSegmentation} disabled={runningML}>
        {runningML ? <ActivityIndicator color="#fff" size="small" /> :
          <Text style={styles.mlBtnText}>🤖 Run ML Segmentation</Text>}
      </TouchableOpacity>

      {/* Segment Filter */}
      <View style={styles.filterRow}>
        {['all', 'loyal', 'at_risk', 'new'].map(seg => (
          <TouchableOpacity key={seg}
            style={[styles.filterChip, filterSegment === seg && styles.filterChipActive]}
            onPress={() => setFilterSegment(seg)}>
            <Text style={filterSegment === seg ? styles.filterChipActiveText : styles.filterChipText}>
              {seg === 'all' ? 'All' : SEGMENT_CONFIG[seg].label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <FlatList
        data={displayed}
        keyExtractor={i => i.id}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); fetchCustomers(); }} />}
        renderItem={({ item }) => {
          const seg = SEGMENT_CONFIG[item.segment] || SEGMENT_CONFIG.new;
          return (
            <View style={[styles.card, { borderLeftColor: seg.color }]}>
              <View style={[styles.segIcon, { backgroundColor: seg.bg }]}>
                <Text style={{ fontSize: 20 }}>{seg.icon}</Text>
              </View>
              <View style={{ flex: 1, marginLeft: 10 }}>
                <Text style={styles.customerName}>{item.name}</Text>
                <Text style={styles.customerPhone}>{item.phone || 'No phone'}</Text>
                <View style={styles.statsRow}>
                  <Text style={styles.stat}>💰 ₹{(item.total_spent || 0).toFixed(0)}</Text>
                  <Text style={styles.stat}>🛒 {item.frequency || 0} orders</Text>
                </View>
              </View>
              <View style={[styles.segBadge, { backgroundColor: seg.bg }]}>
                <Text style={[styles.segBadgeText, { color: seg.color }]}>{seg.label}</Text>
              </View>
            </View>
          );
        }}
        ListEmptyComponent={<Text style={styles.empty}>No customers in this segment</Text>}
      />

      {/* Add Customer FAB */}
      <TouchableOpacity style={styles.fab} onPress={() => setModalVisible(true)}>
        <Text style={styles.fabText}>+ Add</Text>
      </TouchableOpacity>

      {/* Add Modal */}
      <Modal visible={modalVisible} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Add Customer</Text>
            {[
              { field: 'name', label: 'Customer Name *', type: 'default' },
              { field: 'phone', label: 'Phone Number', type: 'phone-pad' },
              { field: 'email', label: 'Email (optional)', type: 'email-address' },
            ].map(({ field, label, type }) => (
              <TextInput key={field} style={styles.input} placeholder={label}
                keyboardType={type} value={form[field]}
                onChangeText={v => setForm({ ...form, [field]: v })} />
            ))}
            <View style={styles.modalBtns}>
              <TouchableOpacity style={styles.cancelBtn} onPress={() => setModalVisible(false)}>
                <Text>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.saveBtn} onPress={handleAddCustomer} disabled={submitting}>
                {submitting ? <ActivityIndicator color="#fff" /> : <Text style={styles.saveBtnText}>Add</Text>}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f6fa' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  mlBtn: { margin: 12, backgroundColor: '#9b59b6', padding: 12, borderRadius: 10, alignItems: 'center' },
  mlBtnText: { color: '#fff', fontWeight: 'bold' },
  filterRow: { flexDirection: 'row', paddingHorizontal: 12, gap: 8, marginBottom: 8 },
  filterChip: { paddingHorizontal: 12, paddingVertical: 6, backgroundColor: '#fff', borderRadius: 20, borderWidth: 1, borderColor: '#ddd' },
  filterChipActive: { backgroundColor: '#6C63FF', borderColor: '#6C63FF' },
  filterChipText: { color: '#666', fontSize: 12 },
  filterChipActiveText: { color: '#fff', fontSize: 12, fontWeight: 'bold' },
  card: { backgroundColor: '#fff', marginHorizontal: 12, marginBottom: 8, borderRadius: 12,
    padding: 12, flexDirection: 'row', alignItems: 'center', elevation: 2, borderLeftWidth: 4 },
  segIcon: { width: 44, height: 44, borderRadius: 22, justifyContent: 'center', alignItems: 'center' },
  customerName: { fontSize: 15, fontWeight: 'bold', color: '#333' },
  customerPhone: { fontSize: 12, color: '#888' },
  statsRow: { flexDirection: 'row', gap: 12, marginTop: 4 },
  stat: { fontSize: 12, color: '#666' },
  segBadge: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 10 },
  segBadgeText: { fontSize: 11, fontWeight: 'bold' },
  empty: { textAlign: 'center', padding: 30, color: '#999', fontSize: 14 },
  fab: { position: 'absolute', right: 16, bottom: 16, backgroundColor: '#6C63FF',
    paddingHorizontal: 20, paddingVertical: 12, borderRadius: 25, elevation: 5 },
  fabText: { color: '#fff', fontWeight: 'bold', fontSize: 14 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalContent: { backgroundColor: '#fff', borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 20 },
  modalTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 14 },
  input: { borderWidth: 1, borderColor: '#ddd', borderRadius: 10, padding: 10, marginBottom: 10 },
  modalBtns: { flexDirection: 'row', gap: 10 },
  cancelBtn: { flex: 1, padding: 12, backgroundColor: '#eee', borderRadius: 10, alignItems: 'center' },
  saveBtn: { flex: 1, padding: 12, backgroundColor: '#6C63FF', borderRadius: 10, alignItems: 'center' },
  saveBtnText: { color: '#fff', fontWeight: 'bold' },
});
