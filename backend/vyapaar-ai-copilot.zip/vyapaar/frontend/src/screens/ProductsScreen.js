import React, { useEffect, useState } from 'react';
import {
  View, Text, FlatList, StyleSheet, TouchableOpacity, Modal,
  TextInput, Alert, ActivityIndicator, RefreshControl
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getProducts, addProduct, updateProduct, deleteProduct } from '../services/api';

const emptyForm = { name: '', price: '', stock: '', threshold: '10', category: '', unit: 'piece' };

export default function ProductsScreen() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [editId, setEditId] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [filterLow, setFilterLow] = useState(false);

  const fetchProducts = async () => {
    const uid = await AsyncStorage.getItem('user_id');
    const res = await getProducts(uid);
    setProducts(res.data.products || []);
    setLoading(false);
    setRefreshing(false);
  };

  useEffect(() => { fetchProducts(); }, []);

  const openAdd = () => { setForm(emptyForm); setEditId(null); setModalVisible(true); };

  const openEdit = (product) => {
    setForm({ name: product.name, price: String(product.price), stock: String(product.stock),
      threshold: String(product.threshold), category: product.category || '', unit: product.unit || 'piece' });
    setEditId(product.id);
    setModalVisible(true);
  };

  const handleSubmit = async () => {
    if (!form.name || !form.price || !form.stock) return Alert.alert('Error', 'Fill all required fields');
    setSubmitting(true);
    const uid = await AsyncStorage.getItem('user_id');
    try {
      if (editId) {
        await updateProduct(editId, { ...form, price: parseFloat(form.price), stock: parseInt(form.stock), threshold: parseInt(form.threshold) });
      } else {
        await addProduct({ ...form, user_id: uid, price: parseFloat(form.price), stock: parseInt(form.stock), threshold: parseInt(form.threshold) });
      }
      setModalVisible(false);
      fetchProducts();
    } catch (e) {
      Alert.alert('Error', 'Failed to save product');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = (id, name) => {
    Alert.alert('Delete Product', `Delete "${name}"?`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: async () => {
        await deleteProduct(id);
        fetchProducts();
      }},
    ]);
  };

  const displayed = filterLow ? products.filter(p => p.stock <= p.threshold) : products;

  if (loading) return <View style={styles.center}><ActivityIndicator color="#6C63FF" size="large" /></View>;

  return (
    <View style={styles.container}>
      <View style={styles.topBar}>
        <TouchableOpacity style={[styles.filterBtn, filterLow && styles.filterActive]}
          onPress={() => setFilterLow(!filterLow)}>
          <Text style={filterLow ? styles.filterActiveText : styles.filterText}>
            {filterLow ? '⚠️ Low Stock' : 'All Products'}
          </Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.addBtn} onPress={openAdd}>
          <Text style={styles.addBtnText}>+ Add Product</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={displayed}
        keyExtractor={i => i.id}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); fetchProducts(); }} />}
        renderItem={({ item }) => (
          <View style={[styles.card, item.stock <= item.threshold && styles.cardWarning]}>
            <View style={{ flex: 1 }}>
              <Text style={styles.productName}>{item.name}</Text>
              <Text style={styles.productMeta}>
                ₹{item.price} · {item.unit} · {item.category || 'General'}
              </Text>
              <View style={styles.stockRow}>
                <Text style={[styles.stockText, item.stock <= item.threshold && styles.stockLow]}>
                  Stock: {item.stock}
                </Text>
                <Text style={styles.thresholdText}>Min: {item.threshold}</Text>
              </View>
            </View>
            <View style={styles.actions}>
              <TouchableOpacity onPress={() => openEdit(item)} style={styles.editBtn}>
                <Text>✏️</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => handleDelete(item.id, item.name)} style={styles.delBtn}>
                <Text>🗑️</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
        ListEmptyComponent={<Text style={styles.empty}>No products found. Add your first product!</Text>}
      />

      {/* Add/Edit Modal */}
      <Modal visible={modalVisible} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>{editId ? 'Edit Product' : 'Add Product'}</Text>
            {[
              { field: 'name', label: 'Product Name *', type: 'default' },
              { field: 'price', label: 'Price (₹) *', type: 'numeric' },
              { field: 'stock', label: 'Stock Quantity *', type: 'numeric' },
              { field: 'threshold', label: 'Low Stock Alert At', type: 'numeric' },
              { field: 'category', label: 'Category', type: 'default' },
              { field: 'unit', label: 'Unit (piece/kg/litre)', type: 'default' },
            ].map(({ field, label, type }) => (
              <TextInput key={field} style={styles.input} placeholder={label}
                keyboardType={type} value={form[field]}
                onChangeText={v => setForm({ ...form, [field]: v })} />
            ))}
            <View style={styles.modalBtns}>
              <TouchableOpacity style={styles.cancelBtn} onPress={() => setModalVisible(false)}>
                <Text style={styles.cancelBtnText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.saveBtn} onPress={handleSubmit} disabled={submitting}>
                {submitting ? <ActivityIndicator color="#fff" /> :
                  <Text style={styles.saveBtnText}>{editId ? 'Update' : 'Add'}</Text>}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f6fa' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  topBar: { flexDirection: 'row', justifyContent: 'space-between', padding: 12, gap: 10 },
  filterBtn: { flex: 1, padding: 10, backgroundColor: '#fff', borderRadius: 10, alignItems: 'center', borderWidth: 1, borderColor: '#ddd' },
  filterActive: { backgroundColor: '#fff3cd', borderColor: '#f39c12' },
  filterText: { color: '#666', fontWeight: 'bold' },
  filterActiveText: { color: '#f39c12', fontWeight: 'bold' },
  addBtn: { flex: 1, padding: 10, backgroundColor: '#6C63FF', borderRadius: 10, alignItems: 'center' },
  addBtnText: { color: '#fff', fontWeight: 'bold' },
  card: { backgroundColor: '#fff', marginHorizontal: 12, marginBottom: 8, borderRadius: 12,
    padding: 14, flexDirection: 'row', alignItems: 'center', elevation: 2 },
  cardWarning: { borderLeftWidth: 3, borderLeftColor: '#e74c3c' },
  productName: { fontSize: 15, fontWeight: 'bold', color: '#333' },
  productMeta: { fontSize: 12, color: '#888', marginTop: 2 },
  stockRow: { flexDirection: 'row', gap: 12, marginTop: 4 },
  stockText: { fontSize: 12, color: '#27ae60', fontWeight: 'bold' },
  stockLow: { color: '#e74c3c' },
  thresholdText: { fontSize: 12, color: '#999' },
  actions: { flexDirection: 'row', gap: 8 },
  editBtn: { padding: 8, backgroundColor: '#f0eeff', borderRadius: 8 },
  delBtn: { padding: 8, backgroundColor: '#fff0f0', borderRadius: 8 },
  empty: { textAlign: 'center', padding: 30, color: '#999', fontSize: 14 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalContent: { backgroundColor: '#fff', borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 20 },
  modalTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 14, color: '#333' },
  input: { borderWidth: 1, borderColor: '#ddd', borderRadius: 10, padding: 10, marginBottom: 10, fontSize: 14 },
  modalBtns: { flexDirection: 'row', gap: 10, marginTop: 4 },
  cancelBtn: { flex: 1, padding: 12, backgroundColor: '#eee', borderRadius: 10, alignItems: 'center' },
  cancelBtnText: { color: '#333', fontWeight: 'bold' },
  saveBtn: { flex: 1, padding: 12, backgroundColor: '#6C63FF', borderRadius: 10, alignItems: 'center' },
  saveBtnText: { color: '#fff', fontWeight: 'bold' },
});
