import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  Alert, ActivityIndicator, KeyboardAvoidingView, Platform
} from 'react-native';
import { createClient } from '@supabase/supabase-js';
import AsyncStorage from '@react-native-async-storage/async-storage';

const SUPABASE_URL = 'https://your-project.supabase.co';
const SUPABASE_ANON_KEY = 'your-anon-key';
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

export default function LoginScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [businessName, setBusinessName] = useState('');
  const [isSignup, setIsSignup] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleAuth = async () => {
    if (!email || !password) return Alert.alert('Error', 'Please fill all fields');
    setLoading(true);
    try {
      if (isSignup) {
        const { data, error } = await supabase.auth.signUp({ email, password });
        if (error) throw error;
        if (data.user) {
          await supabase.from('profiles').upsert({
            id: data.user.id, email, business_name: businessName
          });
          await AsyncStorage.setItem('user_id', data.user.id);
          await AsyncStorage.setItem('email', email);
        }
        Alert.alert('Success', 'Account created! Please verify your email.');
      } else {
        const { data, error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        await AsyncStorage.setItem('user_id', data.user.id);
        await AsyncStorage.setItem('email', email);
        await AsyncStorage.setItem('auth_token', data.session.access_token);
        navigation.replace('Main');
      }
    } catch (e) {
      Alert.alert('Error', e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <View style={styles.card}>
        <Text style={styles.logo}>🏪</Text>
        <Text style={styles.title}>Vyapaar AI Copilot</Text>
        <Text style={styles.subtitle}>Smart Business Assistant</Text>

        {isSignup && (
          <TextInput style={styles.input} placeholder="Business Name" value={businessName}
            onChangeText={setBusinessName} />
        )}
        <TextInput style={styles.input} placeholder="Email" value={email}
          onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" />
        <TextInput style={styles.input} placeholder="Password" value={password}
          onChangeText={setPassword} secureTextEntry />

        <TouchableOpacity style={styles.btn} onPress={handleAuth} disabled={loading}>
          {loading ? <ActivityIndicator color="#fff" /> :
            <Text style={styles.btnText}>{isSignup ? 'Create Account' : 'Login'}</Text>}
        </TouchableOpacity>

        <TouchableOpacity onPress={() => setIsSignup(!isSignup)}>
          <Text style={styles.toggle}>
            {isSignup ? 'Already have an account? Login' : "Don't have an account? Sign Up"}
          </Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', backgroundColor: '#6C63FF', padding: 20 },
  card: { backgroundColor: '#fff', borderRadius: 20, padding: 30, alignItems: 'center', elevation: 5 },
  logo: { fontSize: 60, marginBottom: 10 },
  title: { fontSize: 24, fontWeight: 'bold', color: '#333' },
  subtitle: { fontSize: 14, color: '#666', marginBottom: 25 },
  input: { width: '100%', borderWidth: 1, borderColor: '#ddd', borderRadius: 10, padding: 12,
    marginBottom: 12, fontSize: 15 },
  btn: { backgroundColor: '#6C63FF', width: '100%', padding: 14, borderRadius: 10, alignItems: 'center', marginTop: 5 },
  btnText: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
  toggle: { marginTop: 15, color: '#6C63FF', fontSize: 14 },
});
