import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity,
  ActivityIndicator, RefreshControl, Dimensions } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { LineChart } from 'react-native-chart-kit';
import { getDashboard } from '../services/api';

const W = Dimensions.get('window').width;

export default function DashboardScreen({ navigation }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchDashboard = async () => {
    const uid = await AsyncStorage.getItem('user_id');
    try {
      const res = await getDashboard(uid);
      setData(res.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => { fetchDashboard(); }, []);

  const onRefresh = () => { setRefreshing(true); fetchDashboard(); };

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color="#6C63FF" /></View>;

  const chartData = {
    labels: (data?.daily_sales_chart || []).map(d => d.date.slice(5)),
    datasets: [{ data: (data?.daily_sales_chart || []).map(d => d.revenue || 0) }],
  };

  const score = data?.health_score || 0;
  const scoreColor = score >= 70 ? '#27ae60' : score >= 40 ? '#f39c12' : '#e74c3c';

  return (
    <ScrollView style={styles.container} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.greeting}>Good Morning! 👋</Text>
        <TouchableOpacity onPress={() => navigation.navigate('Notifications')}>
          <Text style={styles.bellIcon}>🔔</Text>
          {(data?.alerts?.length > 0) && <View style={styles.badge}><Text style={styles.badgeText}>{data.alerts.length}</Text></View>}
        </TouchableOpacity>
      </View>

      {/* Health Score */}
      <View style={[styles.scoreCard, { borderColor: scoreColor }]}>
        <Text style={styles.scoreLabel}>Business Health Score</Text>
        <Text style={[styles.scoreValue, { color: scoreColor }]}>{score}/100</Text>
        <Text style={styles.scoreHint}>{score >= 70 ? '🌟 Excellent' : score >= 40 ? '⚠️ Needs Attention' : '🚨 Critical'}</Text>
      </View>

      {/* Stats Row */}
      <View style={styles.statsRow}>
        <StatCard label="This Week" value={`₹${(data?.revenue?.week || 0).toFixed(0)}`} icon="💰" />
        <StatCard label="This Month" value={`₹${(data?.revenue?.month || 0).toFixed(0)}`} icon="📅" />
      </View>
      <View style={styles.statsRow}>
        <StatCard label="Orders (Week)" value={data?.orders?.week || 0} icon="🧾" />
        <StatCard label="Low Stock" value={data?.products?.low_stock || 0} icon="⚠️" color={data?.products?.low_stock > 0 ? '#e74c3c' : '#27ae60'} />
      </View>
      <View style={styles.statsRow}>
        <StatCard label="Total Customers" value={data?.customers?.total || 0} icon="👥" />
        <StatCard label="At Risk" value={data?.customers?.at_risk || 0} icon="🔴" color="#e74c3c" />
      </View>

      {/* Sales Chart */}
      {chartData.labels.length > 0 && (
        <View style={styles.chartCard}>
          <Text style={styles.sectionTitle}>📈 Weekly Revenue</Text>
          <LineChart
            data={chartData}
            width={W - 40}
            height={200}
            chartConfig={{
              backgroundColor: '#fff', backgroundGradientFrom: '#fff', backgroundGradientTo: '#fff',
              decimalPlaces: 0, color: (opacity = 1) => `rgba(108, 99, 255, ${opacity})`,
              labelColor: () => '#666', propsForDots: { r: '4', strokeWidth: '2', stroke: '#6C63FF' },
            }}
            bezier style={{ borderRadius: 10 }}
          />
        </View>
      )}

      {/* Latest Insight */}
      {data?.insights?.length > 0 && (
        <View style={styles.insightCard}>
          <Text style={styles.sectionTitle}>🤖 Latest AI Insight</Text>
          <Text style={styles.insightText}>{data.insights[0]?.content?.slice(0, 200)}...</Text>
          <TouchableOpacity onPress={() => navigation.navigate('Insights')}>
            <Text style={styles.viewMore}>View Full Insights →</Text>
          </TouchableOpacity>
        </View>
      )}
    </ScrollView>
  );
}

function StatCard({ label, value, icon, color }) {
  return (
    <View style={styles.statCard}>
      <Text style={styles.statIcon}>{icon}</Text>
      <Text style={[styles.statValue, color && { color }]}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f6fa', padding: 16 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  greeting: { fontSize: 20, fontWeight: 'bold', color: '#333' },
  bellIcon: { fontSize: 26 },
  badge: { position: 'absolute', top: -4, right: -4, backgroundColor: '#e74c3c', borderRadius: 8,
    minWidth: 16, height: 16, justifyContent: 'center', alignItems: 'center' },
  badgeText: { color: '#fff', fontSize: 10, fontWeight: 'bold' },
  scoreCard: { backgroundColor: '#fff', borderRadius: 16, padding: 20, alignItems: 'center',
    marginBottom: 12, borderWidth: 2, elevation: 3 },
  scoreLabel: { fontSize: 14, color: '#666' },
  scoreValue: { fontSize: 48, fontWeight: 'bold' },
  scoreHint: { fontSize: 14, marginTop: 4 },
  statsRow: { flexDirection: 'row', gap: 10, marginBottom: 10 },
  statCard: { flex: 1, backgroundColor: '#fff', borderRadius: 14, padding: 14,
    alignItems: 'center', elevation: 2 },
  statIcon: { fontSize: 24, marginBottom: 4 },
  statValue: { fontSize: 20, fontWeight: 'bold', color: '#333' },
  statLabel: { fontSize: 11, color: '#888', textAlign: 'center' },
  chartCard: { backgroundColor: '#fff', borderRadius: 16, padding: 16, marginBottom: 12, elevation: 2 },
  sectionTitle: { fontSize: 16, fontWeight: 'bold', color: '#333', marginBottom: 10 },
  insightCard: { backgroundColor: '#6C63FF', borderRadius: 16, padding: 16, marginBottom: 20, elevation: 2 },
  insightText: { color: '#fff', fontSize: 13, lineHeight: 20 },
  viewMore: { color: '#FFD700', marginTop: 8, fontWeight: 'bold' },
});
