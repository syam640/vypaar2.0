import React, { useEffect, useState } from 'react';
import {
  View, Text, FlatList, TouchableOpacity, StyleSheet, Modal,
  TextInput, Alert, ScrollView, ActivityIndicator
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getProducts, getCustomers, createBill } from '../services/api';
import * as ImagePicker from 'expo-image-picker';
import { scanBill } from '../services/api';

export default function BillingScreen() {
  const [products, setProducts] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [cart, setCart] = useState([]);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [showCustomerModal, setShowCustomerModal] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    const uid = await AsyncStorage.getItem('user_id');
    try {
      const [prodRes, custRes] = await Promise.all([getProducts(uid), getCustomers(uid)]);
      setProducts(prodRes.data.products || []);
      setCustomers(custRes.data.customers || []);
    } catch (e) {
      Alert.alert('Error', 'Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  const addToCart = (product) => {
    const existing = cart.find(i => i.product_id === product.id);
    if (existing) {
      setCart(cart.map(i => i.product_id === product.id ? { ...i, quantity: i.quantity + 1 } : i));
    } else {
      setCart([...cart, { product_id: product.id, name: product.name, quantity: 1, unit_price: product.price }]);
    }
  };

  const removeFromCart = (product_id) => setCart(cart.filter(i => i.product_id !== product_id));

  const updateQty = (product_id, qty) => {
    if (qty < 1) return removeFromCart(product_id);
    setCart(cart.map(i => i.product_id === product_id ? { ...i, quantity: qty } : i));
  };

  const cartTotal = cart.reduce((sum, i) => sum + i.unit_price * i.quantity, 0);

  const submitBill = async () => {
    if (cart.length === 0) return Alert.alert('Empty Cart', 'Add products to cart first');
    setSubmitting(true);
    const uid = await AsyncStorage.getItem('user_id');
    try {
      await createBill({
        user_id: uid,
        customer_id: selectedCustomer?.id || null,
        items: cart.map(i => ({ product_id: i.product_id, quantity: i.quantity })),
        payment_method: paymentMethod,
      });
      Alert.alert('✅ Success', `Bill of ₹${cartTotal.toFixed(2)} created!`);
      setCart([]);
      setSelectedCustomer(null);
      fetchData();
    } catch (e) {
      Alert.alert('Error', e.response?.data?.detail || 'Failed to create bill');
    } finally {
      setSubmitting(false);
    }
  };

  const handleOCRScan = async () => {
    const result = await ImagePicker.launchCameraAsync({ quality: 0.8 });
    if (result.canceled) return;
    const formData = new FormData();
    formData.append('file', { uri: result.assets[0].uri, name: 'bill.jpg', type: 'image/jpeg' });
    try {
      const res = await scanBill(formData);
      Alert.alert('OCR Result', `Extracted ${res.data.extracted_items.length} items. Review and confirm.`);
    } catch (e) {
      Alert.alert('OCR Failed', 'Could not extract bill info');
    }
  };

  const filteredProducts = products.filter(p =>
    p.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) return <View style={styles.center}><ActivityIndicator color="#6C63FF" size="large" /></View>;

  return (
    <View style={styles.container}>
      {/* Search */}
      <TextInput style={styles.search} placeholder="🔍 Search products..."
        value={searchQuery} onChangeText={setSearchQuery} />

      {/* OCR Button */}
      <TouchableOpacity style={styles.ocrBtn} onPress={handleOCRScan}>
        <Text style={styles.ocrBtnText}>📷 Scan Bill (OCR)</Text>
      </TouchableOpacity>

      {/* Products Grid */}
      <FlatList
        data={filteredProducts}
        keyExtractor={item => item.id}
        numColumns={2}
        style={{ flex: 1 }}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={[styles.productCard, item.stock === 0 && styles.outOfStock]}
            onPress={() => item.stock > 0 && addToCart(item)}
            disabled={item.stock === 0}
          >
            <Text style={styles.productName}>{item.name}</Text>
            <Text style={styles.productPrice}>₹{item.price}</Text>
            <Text style={[styles.stockText, item.stock <= item.threshold && styles.lowStock]}>
              {item.stock === 0 ? '❌ Out of Stock' : `Stock: ${item.stock}`}
            </Text>
            {cart.find(i => i.product_id === item.id) && (
              <View style={styles.inCartBadge}>
                <Text style={styles.inCartText}>In Cart ✓</Text>
              </View>
            )}
          </TouchableOpacity>
        )}
      />

      {/* Cart Summary */}
      {cart.length > 0 && (
        <View style={styles.cartPanel}>
          <ScrollView style={{ maxHeight: 160 }}>
            {cart.map(item => (
              <View key={item.product_id} style={styles.cartItem}>
                <Text style={styles.cartItemName}>{item.name}</Text>
                <View style={styles.cartQtyControls}>
                  <TouchableOpacity onPress={() => updateQty(item.product_id, item.quantity - 1)}
                    style={styles.qtyBtn}><Text>-</Text></TouchableOpacity>
                  <Text style={styles.qtyText}>{item.quantity}</Text>
                  <TouchableOpacity onPress={() => updateQty(item.product_id, item.quantity + 1)}
                    style={styles.qtyBtn}><Text>+</Text></TouchableOpacity>
                </View>
                <Text style={styles.cartItemTotal}>₹{(item.unit_price * item.quantity).toFixed(0)}</Text>
                <TouchableOpacity onPress={() => removeFromCart(item.product_id)}>
                  <Text style={{ color: '#e74c3c' }}>✕</Text>
                </TouchableOpacity>
              </View>
            ))}
          </ScrollView>

          {/* Customer Selector */}
          <TouchableOpacity style={styles.customerBtn} onPress={() => setShowCustomerModal(true)}>
            <Text style={styles.customerBtnText}>
              {selectedCustomer ? `👤 ${selectedCustomer.name}` : '+ Attach Customer'}
            </Text>
          </TouchableOpacity>

          {/* Payment Method */}
          <View style={styles.paymentRow}>
            {['cash', 'upi', 'card'].map(method => (
              <TouchableOpacity key={method}
                style={[styles.payBtn, paymentMethod === method && styles.payBtnActive]}
                onPress={() => setPaymentMethod(method)}>
                <Text style={paymentMethod === method ? styles.payBtnActiveText : styles.payBtnText}>
                  {method.toUpperCase()}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          <TouchableOpacity style={styles.billBtn} onPress={submitBill} disabled={submitting}>
            {submitting ? <ActivityIndicator color="#fff" /> :
              <Text style={styles.billBtnText}>Create Bill  ₹{cartTotal.toFixed(2)}</Text>}
          </TouchableOpacity>
        </View>
      )}

      {/* Customer Modal */}
      <Modal visible={showCustomerModal} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Select Customer</Text>
            <TouchableOpacity onPress={() => { setSelectedCustomer(null); setShowCustomerModal(false); }}>
              <Text style={styles.modalSkip}>Skip (Walk-in)</Text>
            </TouchableOpacity>
            <FlatList
              data={customers}
              keyExtractor={i => i.id}
              renderItem={({ item }) => (
                <TouchableOpacity style={styles.customerItem}
                  onPress={() => { setSelectedCustomer(item); setShowCustomerModal(false); }}>
                  <Text style={styles.customerItemName}>{item.name}</Text>
                  <Text style={styles.customerItemPhone}>{item.phone}</Text>
                </TouchableOpacity>
              )}
            />
            <TouchableOpacity style={styles.closeBtn} onPress={() => setShowCustomerModal(false)}>
              <Text style={styles.closeBtnText}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f6fa' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  search: { margin: 12, padding: 10, backgroundColor: '#fff', borderRadius: 10,
    borderWidth: 1, borderColor: '#ddd', fontSize: 14 },
  ocrBtn: { marginHorizontal: 12, marginBottom: 8, backgroundColor: '#ff9f43', padding: 10,
    borderRadius: 10, alignItems: 'center' },
  ocrBtnText: { color: '#fff', fontWeight: 'bold' },
  productCard: { flex: 1, margin: 6, backgroundColor: '#fff', borderRadius: 12, padding: 12,
    elevation: 2, alignItems: 'center' },
  outOfStock: { opacity: 0.5 },
  productName: { fontSize: 13, fontWeight: 'bold', textAlign: 'center', color: '#333' },
  productPrice: { fontSize: 16, color: '#6C63FF', fontWeight: 'bold', marginTop: 4 },
  stockText: { fontSize: 11, color: '#27ae60', marginTop: 2 },
  lowStock: { color: '#e74c3c' },
  inCartBadge: { marginTop: 4, backgroundColor: '#6C63FF', borderRadius: 8, paddingHorizontal: 6 },
  inCartText: { color: '#fff', fontSize: 10 },
  cartPanel: { backgroundColor: '#fff', borderTopWidth: 1, borderColor: '#ddd', padding: 12, elevation: 5 },
  cartItem: { flexDirection: 'row', alignItems: 'center', marginBottom: 6, gap: 8 },
  cartItemName: { flex: 1, fontSize: 13, color: '#333' },
  cartQtyControls: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  qtyBtn: { backgroundColor: '#eee', borderRadius: 5, width: 26, height: 26, justifyContent: 'center', alignItems: 'center' },
  qtyText: { fontSize: 14, fontWeight: 'bold', minWidth: 20, textAlign: 'center' },
  cartItemTotal: { fontSize: 13, fontWeight: 'bold', color: '#6C63FF', minWidth: 45 },
  customerBtn: { backgroundColor: '#f0eeff', padding: 8, borderRadius: 8, alignItems: 'center', marginBottom: 8 },
  customerBtnText: { color: '#6C63FF', fontWeight: 'bold' },
  paymentRow: { flexDirection: 'row', gap: 8, marginBottom: 8 },
  payBtn: { flex: 1, padding: 8, borderRadius: 8, borderWidth: 1, borderColor: '#ddd', alignItems: 'center' },
  payBtnActive: { backgroundColor: '#6C63FF', borderColor: '#6C63FF' },
  payBtnText: { color: '#666', fontSize: 12, fontWeight: 'bold' },
  payBtnActiveText: { color: '#fff', fontSize: 12, fontWeight: 'bold' },
  billBtn: { backgroundColor: '#6C63FF', padding: 14, borderRadius: 12, alignItems: 'center' },
  billBtnText: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalContent: { backgroundColor: '#fff', borderTopLeftRadius: 20, borderTopRightRadius: 20,
    padding: 20, maxHeight: '70%' },
  modalTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 12, color: '#333' },
  modalSkip: { color: '#999', marginBottom: 10 },
  customerItem: { padding: 12, borderBottomWidth: 1, borderColor: '#f0f0f0' },
  customerItemName: { fontSize: 15, fontWeight: 'bold', color: '#333' },
  customerItemPhone: { fontSize: 12, color: '#888' },
  closeBtn: { backgroundColor: '#eee', padding: 12, borderRadius: 10, alignItems: 'center', marginTop: 10 },
  closeBtnText: { color: '#333', fontWeight: 'bold' },
});
