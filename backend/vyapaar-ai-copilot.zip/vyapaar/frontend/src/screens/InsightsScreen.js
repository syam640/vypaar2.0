import React, { useEffect, useState } from 'react';
import {
  View, Text, ScrollView, StyleSheet, TouchableOpacity,
  ActivityIndicator, RefreshControl, Alert
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { generateInsights, getInsights, getDemandForecast, getAnomalies } from '../services/api';

export default function InsightsScreen() {
  const [insights, setInsights] = useState([]);
  const [forecast, setForecast] = useState([]);
  const [anomalies, setAnomalies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [forecasting, setForecasting] = useState(false);

  const fetchAll = async () => {
    const uid = await AsyncStorage.getItem('user_id');
    try {
      const [insRes, foreRes, anomRes] = await Promise.all([
        getInsights(uid),
        getDemandForecast(uid).catch(() => ({ data: { forecast: [] } })),
        getAnomalies(uid).catch(() => ({ data: { anomalies: [] } })),
      ]);
      setInsights(insRes.data.insights || []);
      setForecast(foreRes.data.forecast || []);
      setAnomalies(anomRes.data.anomalies || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchAll(); }, []);

  const handleGenerateInsight = async () => {
    setGenerating(true);
    const uid = await AsyncStorage.getItem('user_id');
    try {
      await generateInsights(uid, 'en');
      await fetchAll();
      Alert.alert('✅ Done', 'New AI insight generated!');
    } catch (e) {
      Alert.alert('Error', 'Failed to generate insight');
    } finally {
      setGenerating(false);
    }
  };

  const handleForecast = async () => {
    setForecasting(true);
    const uid = await AsyncStorage.getItem('user_id');
    try {
      const res = await getDemandForecast(uid);
      setForecast(res.data.forecast || []);
      Alert.alert('✅ Done', '7-day demand forecast ready!');
    } catch (e) {
      Alert.alert('Error', e.response?.data?.detail || 'Need more sales data');
    } finally {
      setForecasting(false);
    }
  };

  if (loading) return <View style={styles.center}><ActivityIndicator color="#6C63FF" size="large" /></View>;

  return (
    <ScrollView style={styles.container}
      refreshControl={<RefreshControl refreshing={loading} onRefresh={fetchAll} />}>

      {/* Action Buttons */}
      <View style={styles.btnRow}>
        <TouchableOpacity style={styles.actionBtn} onPress={handleGenerateInsight} disabled={generating}>
          {generating ? <ActivityIndicator color="#fff" size="small" /> :
            <Text style={styles.actionBtnText}>🤖 Generate AI Insight</Text>}
        </TouchableOpacity>
        <TouchableOpacity style={[styles.actionBtn, styles.actionBtn2]} onPress={handleForecast} disabled={forecasting}>
          {forecasting ? <ActivityIndicator color="#fff" size="small" /> :
            <Text style={styles.actionBtnText}>📈 Run Forecast</Text>}
        </TouchableOpacity>
      </View>

      {/* 7-Day Demand Forecast */}
      {forecast.length > 0 && (
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>📈 7-Day Demand Forecast</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {forecast.map((f, i) => (
              <View key={i} style={styles.forecastCard}>
                <Text style={styles.forecastDate}>{f.date?.slice(5)}</Text>
                <Text style={styles.forecastQty}>{Math.round(f.predicted_qty || 0)}</Text>
                <Text style={styles.forecastLabel}>units</Text>
                <View style={[styles.forecastBar, { height: Math.max(4, (f.predicted_qty || 0) * 2) }]} />
              </View>
            ))}
          </ScrollView>
        </View>
      )}

      {/* Anomalies */}
      {anomalies.length > 0 && (
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>🚨 Sales Anomalies Detected</Text>
          {anomalies.map((a, i) => (
            <View key={i} style={[styles.anomalyCard, a.type === 'spike' ? styles.spike : styles.drop]}>
              <Text style={styles.anomalyIcon}>{a.type === 'spike' ? '📈' : '📉'}</Text>
              <View style={{ flex: 1 }}>
                <Text style={styles.anomalyDate}>{a.date}</Text>
                <Text style={styles.anomalyMsg}>
                  Revenue {a.type === 'spike' ? 'spiked' : 'dropped'} by {Math.abs(a.pct_from_average || 0).toFixed(0)}% (₹{a.revenue})
                </Text>
              </View>
              <View style={[styles.severityBadge, a.severity === 'high' ? styles.severityHigh : styles.severityMed]}>
                <Text style={styles.severityText}>{a.severity}</Text>
              </View>
            </View>
          ))}
        </View>
      )}

      {/* AI Insights */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>🤖 AI Business Insights</Text>
        {insights.length === 0 ? (
          <View style={styles.emptyCard}>
            <Text style={styles.emptyText}>No insights yet. Tap "Generate AI Insight" to start!</Text>
          </View>
        ) : insights.map((insight, i) => (
          <View key={i} style={styles.insightCard}>
            <View style={styles.insightHeader}>
              <Text style={styles.insightType}>{insight.insight_type === 'daily' ? '📅 Daily Report' : '🔔 Alert'}</Text>
              <Text style={styles.insightDate}>{insight.created_at?.slice(0, 10)}</Text>
            </View>
            <Text style={styles.insightText}>{insight.content}</Text>
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f6fa' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  btnRow: { flexDirection: 'row', gap: 10, margin: 12 },
  actionBtn: { flex: 1, backgroundColor: '#6C63FF', padding: 12, borderRadius: 10, alignItems: 'center' },
  actionBtn2: { backgroundColor: '#27ae60' },
  actionBtnText: { color: '#fff', fontWeight: 'bold', fontSize: 13 },
  section: { marginHorizontal: 12, marginBottom: 16 },
  sectionTitle: { fontSize: 16, fontWeight: 'bold', color: '#333', marginBottom: 10 },
  forecastCard: { backgroundColor: '#fff', borderRadius: 12, padding: 12, marginRight: 8,
    alignItems: 'center', width: 70, elevation: 2 },
  forecastDate: { fontSize: 11, color: '#888' },
  forecastQty: { fontSize: 22, fontWeight: 'bold', color: '#6C63FF', marginTop: 4 },
  forecastLabel: { fontSize: 10, color: '#999' },
  forecastBar: { width: 30, backgroundColor: '#6C63FF', borderRadius: 4, marginTop: 6, opacity: 0.3 },
  anomalyCard: { flexDirection: 'row', alignItems: 'center', borderRadius: 10, padding: 12,
    marginBottom: 8, gap: 10 },
  spike: { backgroundColor: '#fff8f0', borderLeftWidth: 3, borderLeftColor: '#f39c12' },
  drop: { backgroundColor: '#fff0f0', borderLeftWidth: 3, borderLeftColor: '#e74c3c' },
  anomalyIcon: { fontSize: 24 },
  anomalyDate: { fontSize: 12, color: '#666', fontWeight: 'bold' },
  anomalyMsg: { fontSize: 13, color: '#333', marginTop: 2 },
  severityBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8 },
  severityHigh: { backgroundColor: '#fdeaea' },
  severityMed: { backgroundColor: '#fff3cd' },
  severityText: { fontSize: 10, fontWeight: 'bold', color: '#333' },
  emptyCard: { backgroundColor: '#fff', borderRadius: 12, padding: 20, alignItems: 'center' },
  emptyText: { color: '#999', textAlign: 'center' },
  insightCard: { backgroundColor: '#fff', borderRadius: 12, padding: 16, marginBottom: 10, elevation: 2 },
  insightHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  insightType: { fontSize: 13, fontWeight: 'bold', color: '#6C63FF' },
  insightDate: { fontSize: 12, color: '#999' },
  insightText: { fontSize: 13, color: '#333', lineHeight: 20 },
});
