import React, { useEffect, useState } from 'react';
import {
  View, Text, FlatList, StyleSheet, TouchableOpacity,
  ActivityIndicator, RefreshControl
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = 'https://your-project.supabase.co';
const SUPABASE_ANON_KEY = 'your-anon-key';
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

const ALERT_ICONS = {
  low_stock: '⚠️', anomaly: '📊', at_risk_customer: '👤', forecast: '📈', default: '🔔'
};

export default function NotificationsScreen() {
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchAlerts = async () => {
    const uid = await AsyncStorage.getItem('user_id');
    const { data } = await supabase
      .from('alerts')
      .select('*')
      .eq('user_id', uid)
      .order('created_at', { ascending: false })
      .limit(50);
    setAlerts(data || []);
    setLoading(false);
    setRefreshing(false);
  };

  useEffect(() => { fetchAlerts(); }, []);

  const markRead = async (id) => {
    await supabase.from('alerts').update({ is_read: true }).eq('id', id);
    setAlerts(prev => prev.map(a => a.id === id ? { ...a, is_read: true } : a));
  };

  const markAllRead = async () => {
    const uid = await AsyncStorage.getItem('user_id');
    await supabase.from('alerts').update({ is_read: true }).eq('user_id', uid);
    setAlerts(prev => prev.map(a => ({ ...a, is_read: true })));
  };

  if (loading) return <View style={styles.center}><ActivityIndicator color="#6C63FF" size="large" /></View>;

  const unreadCount = alerts.filter(a => !a.is_read).length;

  return (
    <View style={styles.container}>
      {unreadCount > 0 && (
        <TouchableOpacity style={styles.markAllBtn} onPress={markAllRead}>
          <Text style={styles.markAllText}>Mark all read ({unreadCount} unread)</Text>
        </TouchableOpacity>
      )}

      <FlatList
        data={alerts}
        keyExtractor={i => i.id}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); fetchAlerts(); }} />}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={[styles.alertCard, !item.is_read && styles.alertUnread]}
            onPress={() => markRead(item.id)}
          >
            <Text style={styles.alertIcon}>{ALERT_ICONS[item.type] || ALERT_ICONS.default}</Text>
            <View style={{ flex: 1 }}>
              <Text style={styles.alertType}>{item.type?.replace(/_/g, ' ').toUpperCase()}</Text>
              <Text style={styles.alertMsg}>{item.message}</Text>
              <Text style={styles.alertTime}>{item.created_at?.slice(0, 16).replace('T', ' ')}</Text>
            </View>
            {!item.is_read && <View style={styles.unreadDot} />}
          </TouchableOpacity>
        )}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Text style={styles.emptyIcon}>🎉</Text>
            <Text style={styles.emptyText}>No alerts! Business is running smoothly.</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f6fa' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  markAllBtn: { margin: 12, backgroundColor: '#6C63FF', padding: 10, borderRadius: 10, alignItems: 'center' },
  markAllText: { color: '#fff', fontWeight: 'bold' },
  alertCard: { backgroundColor: '#fff', marginHorizontal: 12, marginBottom: 8,
    borderRadius: 12, padding: 14, flexDirection: 'row', alignItems: 'center', gap: 10, elevation: 1 },
  alertUnread: { borderLeftWidth: 3, borderLeftColor: '#6C63FF', backgroundColor: '#f9f8ff' },
  alertIcon: { fontSize: 26 },
  alertType: { fontSize: 11, color: '#6C63FF', fontWeight: 'bold', marginBottom: 2 },
  alertMsg: { fontSize: 13, color: '#333', lineHeight: 18 },
  alertTime: { fontSize: 11, color: '#999', marginTop: 4 },
  unreadDot: { width: 10, height: 10, borderRadius: 5, backgroundColor: '#6C63FF' },
  empty: { alignItems: 'center', padding: 40 },
  emptyIcon: { fontSize: 48, marginBottom: 10 },
  emptyText: { color: '#999', fontSize: 14, textAlign: 'center' },
});
