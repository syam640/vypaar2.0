from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routers import billing, dashboard, products, customers, ml, insights, ocr
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from automation.scheduler import run_daily_automation

app = FastAPI(
    title="Vyapaar AI Copilot API",
    description="Autonomous AI Operating System for Small Businesses",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routers
app.include_router(billing.router, prefix="/bill", tags=["Billing"])
app.include_router(dashboard.router, prefix="/dashboard", tags=["Dashboard"])
app.include_router(products.router, prefix="/products", tags=["Products"])
app.include_router(customers.router, prefix="/customers", tags=["Customers"])
app.include_router(ml.router, prefix="/ml", tags=["Machine Learning"])
app.include_router(insights.router, prefix="/insights", tags=["AI Insights"])
app.include_router(ocr.router, prefix="/ocr", tags=["OCR"])

# Scheduler for daily automation
scheduler = AsyncIOScheduler()

@app.on_event("startup")
async def startup():
    scheduler.add_job(run_daily_automation, "cron", hour=8, minute=0)
    scheduler.start()
    print("✅ Vyapaar AI Copilot Backend Started")

@app.on_event("shutdown")
async def shutdown():
    scheduler.shutdown()

@app.get("/")
def root():
    return {"status": "running", "app": "Vyapaar AI Copilot"}

@app.get("/health")
def health():
    return {"status": "healthy"}
