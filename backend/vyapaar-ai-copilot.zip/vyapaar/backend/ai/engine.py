import openai
import google.generativeai as genai
from core.config import OPENAI_API_KEY, GEMINI_API_KEY
import json

openai.api_key = OPENAI_API_KEY
if GEMINI_API_KEY:
    genai.configure(api_key=GEMINI_API_KEY)

INSIGHT_PROMPT_TEMPLATE = """
You are a smart business advisor for a small Indian retail business.

Analyze this real business data and generate actionable insights:

SALES DATA (last 50 transactions):
{sales_summary}

INVENTORY STATUS:
{inventory_summary}

CUSTOMER OVERVIEW:
{customer_summary}

DEMAND FORECAST (next 7 days):
{forecast_summary}

LANGUAGE: {language}

Generate a concise business intelligence report with:
1. 📊 Current Business Status (2-3 sentences)
2. ⚠️ Key Risks & Alerts (bullet points)
3. 💡 Top 3 Actionable Recommendations
4. 🎯 Today's Priority Actions

Keep it practical, specific to the data, and in {language} language if not English.
Use simple language a small business owner can understand.
"""

async def generate_ai_insights(context: dict) -> str:
    sales = context.get("sales", [])
    products = context.get("products", [])
    customers = context.get("customers", [])
    forecasts = context.get("forecasts", [])
    language = context.get("language", "en")

    # Summarize data for prompt
    total_revenue = sum(s.get("total_price", 0) for s in sales)
    low_stock = [p for p in products if p.get("stock", 0) <= p.get("threshold", 10)]
    loyal = sum(1 for c in customers if c.get("segment") == "loyal")
    at_risk = sum(1 for c in customers if c.get("segment") == "at_risk")
    avg_forecast = sum(f.get("predicted_qty", 0) for f in forecasts) / max(len(forecasts), 1)

    prompt = INSIGHT_PROMPT_TEMPLATE.format(
        sales_summary=f"Total revenue from last {len(sales)} transactions: ₹{total_revenue:.0f}. Average per transaction: ₹{total_revenue/max(len(sales),1):.0f}",
        inventory_summary=f"{len(products)} products total. {len(low_stock)} below threshold: {[p['name'] for p in low_stock[:5]]}",
        customer_summary=f"{len(customers)} customers. Loyal: {loyal}, At-risk: {at_risk}, New: {len(customers)-loyal-at_risk}",
        forecast_summary=f"Average predicted daily demand next 7 days: {avg_forecast:.1f} units. {json.dumps([{'date':f['forecast_date'],'qty':f['predicted_quantity']} for f in forecasts[:3]])}",
        language=language
    )

    # Try OpenAI first
    if OPENAI_API_KEY:
        try:
            client = openai.OpenAI(api_key=OPENAI_API_KEY)
            response = client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "You are a business intelligence advisor for small Indian retail businesses."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=800,
                temperature=0.7
            )
            return response.choices[0].message.content
        except Exception as e:
            print(f"OpenAI failed: {e}")

    # Fallback to Gemini
    if GEMINI_API_KEY:
        try:
            model = genai.GenerativeModel("gemini-1.5-flash")
            response = model.generate_content(prompt)
            return response.text
        except Exception as e:
            print(f"Gemini failed: {e}")

    return "⚠️ AI insights unavailable. Please check API keys. Business data collected successfully."
