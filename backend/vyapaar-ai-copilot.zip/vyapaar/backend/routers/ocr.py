from fastapi import APIRouter, UploadFile, File, HTTPException
import pytesseract
from PIL import Image
import io, re

router = APIRouter()

@router.post("/scan-bill")
async def scan_bill(file: UploadFile = File(...)):
    """Extract bill info from image using OCR"""
    try:
        contents = await file.read()
        image = Image.open(io.BytesIO(contents))
        
        # OCR extraction
        text = pytesseract.image_to_string(image)
        
        # Parse structured data from OCR text
        lines = [l.strip() for l in text.split('\n') if l.strip()]
        items = []
        total = 0
        
        for line in lines:
            # Try to extract: product name, quantity, price patterns
            # Example: "Rice 2kg  120" or "Product x2 ₹50"
            qty_price = re.findall(r'(\d+(?:\.\d+)?)', line)
            if len(qty_price) >= 2:
                name_part = re.sub(r'[\d₹Rs.]+', '', line).strip()
                if name_part and len(name_part) > 2:
                    qty = float(qty_price[0])
                    price = float(qty_price[-1])
                    items.append({
                        "product_name": name_part,
                        "quantity": qty,
                        "price": price,
                        "total": qty * price
                    })
                    total += qty * price
        
        return {
            "raw_text": text,
            "extracted_items": items,
            "estimated_total": total,
            "success": True
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"OCR failed: {str(e)}")

@router.post("/voice-to-bill")
async def voice_to_bill(audio: UploadFile = File(...)):
    """Convert voice recording to bill structure"""
    import speech_recognition as sr
    
    try:
        contents = await audio.read()
        
        recognizer = sr.Recognizer()
        with sr.AudioFile(io.BytesIO(contents)) as source:
            audio_data = recognizer.record(source)
        
        text = recognizer.recognize_google(audio_data, language="hi-IN")  # Hindi + English
        
        # Parse spoken bill: "2 kg rice 60 rupees, 1 oil 120"
        items = []
        parts = re.split(r'[,|and|aur]', text.lower())
        for part in parts:
            nums = re.findall(r'\d+(?:\.\d+)?', part)
            words = re.sub(r'\d+|rupees?|rs\.?|kg|litre?|piece', '', part).strip()
            if nums and words:
                items.append({
                    "product_name": words.strip(),
                    "quantity": float(nums[0]) if nums else 1,
                    "price": float(nums[-1]) if len(nums) > 1 else 0
                })
        
        return {"transcribed": text, "extracted_items": items, "success": True}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Voice processing failed: {str(e)}")
