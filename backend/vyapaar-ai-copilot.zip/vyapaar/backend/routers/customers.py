from fastapi import APIRouter
from pydantic import BaseModel
from typing import Optional
from core.database import get_supabase

router = APIRouter()

class CustomerCreate(BaseModel):
    user_id: str
    name: str
    phone: Optional[str] = None
    email: Optional[str] = None

@router.get("/{user_id}")
def get_customers(user_id: str):
    db = get_supabase()
    res = db.table("customers").select("*").eq("user_id", user_id).order("total_spent", desc=True).execute()
    return {"customers": res.data}

@router.post("/add")
def add_customer(customer: CustomerCreate):
    db = get_supabase()
    res = db.table("customers").insert(customer.dict()).execute()
    return {"success": True, "customer": res.data[0]}

@router.get("/{user_id}/segments")
def get_segments(user_id: str):
    db = get_supabase()
    res = db.table("customers").select("id, name, segment, total_spent, frequency, last_purchase").eq("user_id", user_id).execute()
    customers = res.data or []
    return {
        "loyal": [c for c in customers if c.get("segment") == "loyal"],
        "at_risk": [c for c in customers if c.get("segment") == "at_risk"],
        "new": [c for c in customers if c.get("segment") == "new"]
    }
