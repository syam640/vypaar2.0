from fastapi import APIRouter, HTTPException
from core.database import get_supabase
from ml.forecasting import predict_demand
from ml.segmentation import segment_customers
from ml.anomaly import detect_anomaly

router = APIRouter()

@router.get("/predict-demand/{user_id}")
async def demand_forecast(user_id: str, product_id: str = None):
    db = get_supabase()
    query = db.table("sales").select("product_id, quantity, timestamp, products(name)").eq("user_id", user_id)
    if product_id:
        query = query.eq("product_id", product_id)
    sales_data = query.execute()
    
    if not sales_data.data or len(sales_data.data) < 5:
        raise HTTPException(status_code=400, detail="Not enough sales data for forecasting (need at least 5 records)")
    
    forecast = predict_demand(sales_data.data)
    
    # Store forecasts in DB
    for f in forecast:
        db.table("forecasts").upsert({
            "user_id": user_id,
            "product_id": f.get("product_id"),
            "forecast_date": f["date"],
            "predicted_quantity": f["predicted_qty"],
            "confidence": f.get("confidence", 0.8)
        }).execute()
    
    return {"forecast": forecast}

@router.get("/customer-segmentation/{user_id}")
async def customer_segmentation(user_id: str):
    db = get_supabase()
    customers = db.table("customers").select("*").eq("user_id", user_id).execute()
    sales = db.table("sales").select("customer_id, total_price, timestamp").eq("user_id", user_id).execute()
    
    if not customers.data:
        raise HTTPException(status_code=400, detail="No customers found")
    
    segments = segment_customers(customers.data, sales.data or [])
    
    # Update segments in DB
    for seg in segments:
        db.table("customers").update({"segment": seg["segment"]}).eq("id", seg["customer_id"]).execute()
    
    return {"segments": segments}

@router.get("/anomaly/{user_id}")
async def anomaly_detection(user_id: str):
    db = get_supabase()
    sales = db.table("sales").select("total_price, timestamp, quantity").eq("user_id", user_id).order("timestamp").execute()
    
    if not sales.data or len(sales.data) < 7:
        return {"anomalies": [], "message": "Not enough data"}
    
    anomalies = detect_anomaly(sales.data)
    return {"anomalies": anomalies}
