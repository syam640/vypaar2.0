from fastapi import APIRouter
from core.database import get_supabase
from datetime import datetime, timedelta

router = APIRouter()

@router.get("/{user_id}")
def get_dashboard(user_id: str):
    db = get_supabase()
    now = datetime.utcnow()
    week_ago = (now - timedelta(days=7)).isoformat()
    month_ago = (now - timedelta(days=30)).isoformat()

    # Sales this week
    sales_week = db.table("sales").select("total_price, timestamp, quantity").eq("user_id", user_id).gte("timestamp", week_ago).execute()
    
    # Sales this month
    sales_month = db.table("sales").select("total_price").eq("user_id", user_id).gte("timestamp", month_ago).execute()

    # Total revenue
    revenue_week = sum(s["total_price"] for s in (sales_week.data or []))
    revenue_month = sum(s["total_price"] for s in (sales_month.data or []))

    # Product count
    products = db.table("products").select("id, stock, threshold").eq("user_id", user_id).execute()
    low_stock_count = sum(1 for p in (products.data or []) if p["stock"] <= p["threshold"])

    # Customer count
    customers = db.table("customers").select("id, segment").eq("user_id", user_id).execute()
    
    # Unread alerts
    alerts = db.table("alerts").select("id, type, message, created_at").eq("user_id", user_id).eq("is_read", False).order("created_at", desc=True).limit(5).execute()

    # Recent insights
    insights = db.table("insights").select("*").eq("user_id", user_id).order("created_at", desc=True).limit(3).execute()

    # Daily sales chart (last 7 days)
    daily_sales = {}
    for s in (sales_week.data or []):
        day = s["timestamp"][:10]
        daily_sales[day] = daily_sales.get(day, 0) + s["total_price"]

    # Business health score (0-100)
    score = 70
    if low_stock_count > 0: score -= (low_stock_count * 5)
    if revenue_week > 0: score += min(20, int(revenue_week / 1000))
    score = max(0, min(100, score))

    return {
        "revenue": {"week": revenue_week, "month": revenue_month},
        "orders": {"week": len(sales_week.data or [])},
        "products": {"total": len(products.data or []), "low_stock": low_stock_count},
        "customers": {
            "total": len(customers.data or []),
            "loyal": sum(1 for c in (customers.data or []) if c.get("segment") == "loyal"),
            "at_risk": sum(1 for c in (customers.data or []) if c.get("segment") == "at_risk")
        },
        "health_score": score,
        "daily_sales_chart": [{"date": k, "revenue": v} for k, v in sorted(daily_sales.items())],
        "alerts": alerts.data or [],
        "insights": insights.data or []
    }
