from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional
from core.database import get_supabase

router = APIRouter()

class ProductCreate(BaseModel):
    user_id: str
    name: str
    price: float
    stock: int
    threshold: int = 10
    category: Optional[str] = None
    unit: str = "piece"

class ProductUpdate(BaseModel):
    name: Optional[str] = None
    price: Optional[float] = None
    stock: Optional[int] = None
    threshold: Optional[int] = None

@router.get("/{user_id}")
def get_products(user_id: str):
    db = get_supabase()
    res = db.table("products").select("*").eq("user_id", user_id).order("name").execute()
    return {"products": res.data}

@router.post("/add")
def add_product(product: ProductCreate):
    db = get_supabase()
    res = db.table("products").insert(product.dict()).execute()
    return {"success": True, "product": res.data[0]}

@router.put("/{product_id}")
def update_product(product_id: str, data: ProductUpdate):
    db = get_supabase()
    update_data = {k: v for k, v in data.dict().items() if v is not None}
    res = db.table("products").update(update_data).eq("id", product_id).execute()
    return {"success": True, "product": res.data[0]}

@router.delete("/{product_id}")
def delete_product(product_id: str):
    db = get_supabase()
    db.table("products").delete().eq("id", product_id).execute()
    return {"success": True}

@router.get("/{user_id}/low-stock")
def low_stock(user_id: str):
    db = get_supabase()
    res = db.table("products").select("*").eq("user_id", user_id).execute()
    low = [p for p in (res.data or []) if p["stock"] <= p["threshold"]]
    return {"low_stock_products": low}
