from fastapi import APIRouter
from pydantic import BaseModel
from core.database import get_supabase
from ai.engine import generate_ai_insights
from datetime import datetime

router = APIRouter()

class InsightRequest(BaseModel):
    user_id: str
    language: str = "en"

@router.post("/generate")
async def generate_insights(req: InsightRequest):
    db = get_supabase()

    # Gather context
    sales = db.table("sales").select("total_price, quantity, timestamp").eq("user_id", req.user_id).order("timestamp", desc=True).limit(50).execute()
    products = db.table("products").select("name, stock, threshold, price").eq("user_id", req.user_id).execute()
    customers = db.table("customers").select("segment, total_spent, frequency").eq("user_id", req.user_id).execute()
    forecasts = db.table("forecasts").select("*").eq("user_id", req.user_id).order("forecast_date").limit(7).execute()

    context = {
        "sales": sales.data or [],
        "products": products.data or [],
        "customers": customers.data or [],
        "forecasts": forecasts.data or [],
        "language": req.language
    }

    insight_text = await generate_ai_insights(context)

    # Store insight
    db.table("insights").insert({
        "user_id": req.user_id,
        "content": insight_text,
        "insight_type": "daily",
        "created_at": datetime.utcnow().isoformat()
    }).execute()

    return {"insight": insight_text, "generated_at": datetime.utcnow().isoformat()}

@router.get("/{user_id}")
def get_insights(user_id: str, limit: int = 10):
    db = get_supabase()
    res = db.table("insights").select("*").eq("user_id", user_id).order("created_at", desc=True).limit(limit).execute()
    return {"insights": res.data}
