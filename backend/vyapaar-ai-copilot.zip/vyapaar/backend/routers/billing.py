from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional
from datetime import datetime
from core.database import get_supabase
from automation.triggers import check_stock_alert, check_anomaly

router = APIRouter()

class BillItem(BaseModel):
    product_id: str
    quantity: int

class BillCreate(BaseModel):
    user_id: str
    customer_id: Optional[str] = None
    items: list[BillItem]
    payment_method: str = "cash"

@router.post("/create")
async def create_bill(bill: BillCreate):
    db = get_supabase()
    created_sales = []

    for item in bill.items:
        # Get product
        product_res = db.table("products").select("*").eq("id", item.product_id).single().execute()
        if not product_res.data:
            raise HTTPException(status_code=404, detail=f"Product {item.product_id} not found")
        
        product = product_res.data
        if product["stock"] < item.quantity:
            raise HTTPException(status_code=400, detail=f"Insufficient stock for {product['name']}")

        total_price = product["price"] * item.quantity

        # Insert sale
        sale_data = {
            "user_id": bill.user_id,
            "product_id": item.product_id,
            "customer_id": bill.customer_id,
            "quantity": item.quantity,
            "unit_price": product["price"],
            "total_price": total_price,
            "payment_method": bill.payment_method,
            "timestamp": datetime.utcnow().isoformat()
        }
        sale_res = db.table("sales").insert(sale_data).execute()
        created_sales.append(sale_res.data[0])

        # Update stock
        new_stock = product["stock"] - item.quantity
        db.table("products").update({"stock": new_stock}).eq("id", item.product_id).execute()

        # Check stock alert
        await check_stock_alert(bill.user_id, product, new_stock)

    # Update customer stats
    if bill.customer_id:
        total_bill = sum(s["total_price"] for s in created_sales)
        customer_res = db.table("customers").select("*").eq("id", bill.customer_id).single().execute()
        if customer_res.data:
            c = customer_res.data
            db.table("customers").update({
                "last_purchase": datetime.utcnow().isoformat(),
                "total_spent": (c["total_spent"] or 0) + total_bill,
                "frequency": (c["frequency"] or 0) + 1
            }).eq("id", bill.customer_id).execute()

    # Check for anomalies async
    await check_anomaly(bill.user_id)

    return {"success": True, "sales": created_sales, "message": "Bill created successfully"}

@router.get("/history/{user_id}")
def bill_history(user_id: str, limit: int = 50):
    db = get_supabase()
    res = db.table("sales").select(
        "*, products(name, price), customers(name, phone)"
    ).eq("user_id", user_id).order("timestamp", desc=True).limit(limit).execute()
    return {"sales": res.data}
