from core.database import get_supabase
from automation.triggers import check_at_risk_customers
from ai.engine import generate_ai_insights
from datetime import datetime

async def run_daily_automation():
    """Runs every morning at 8 AM for all users."""
    print(f"🤖 Running daily automation at {datetime.utcnow()}")
    db = get_supabase()

    users = db.table("profiles").select("id, language").execute()
    for user in (users.data or []):
        uid = user["id"]
        try:
            # 1. Check at-risk customers
            await check_at_risk_customers(uid)

            # 2. Run ML segmentation
            from ml.segmentation import segment_customers
            customers = db.table("customers").select("*").eq("user_id", uid).execute()
            sales = db.table("sales").select("customer_id, total_price, timestamp").eq("user_id", uid).execute()
            if customers.data:
                segments = segment_customers(customers.data, sales.data or [])
                for seg in segments:
                    db.table("customers").update({"segment": seg["segment"]}).eq("id", seg["customer_id"]).execute()

            # 3. Generate AI insights
            products = db.table("products").select("*").eq("user_id", uid).execute()
            forecasts = db.table("forecasts").select("*").eq("user_id", uid).order("forecast_date").limit(7).execute()
            context = {
                "sales": sales.data or [],
                "products": products.data or [],
                "customers": customers.data or [],
                "forecasts": forecasts.data or [],
                "language": user.get("language", "en")
            }
            insight = await generate_ai_insights(context)
            db.table("insights").insert({
                "user_id": uid,
                "content": insight,
                "insight_type": "daily",
                "created_at": datetime.utcnow().isoformat()
            }).execute()

            print(f"✅ Automation done for user {uid}")
        except Exception as e:
            print(f"❌ Automation failed for user {uid}: {e}")
