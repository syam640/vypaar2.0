from core.database import get_supabase
from datetime import datetime

async def check_stock_alert(user_id: str, product: dict, new_stock: int):
    """Create alert if stock drops below threshold."""
    if new_stock <= product.get("threshold", 10):
        db = get_supabase()
        db.table("alerts").insert({
            "user_id": user_id,
            "type": "low_stock",
            "message": f"⚠️ Low stock alert: '{product['name']}' has only {new_stock} units left (threshold: {product.get('threshold', 10)}). Restock soon!",
            "created_at": datetime.utcnow().isoformat()
        }).execute()

async def check_anomaly(user_id: str):
    """Detect and alert on sales anomalies."""
    from ml.anomaly import detect_anomaly
    db = get_supabase()
    
    sales = db.table("sales").select("total_price, timestamp, quantity").eq("user_id", user_id).order("timestamp").execute()
    if not sales.data or len(sales.data) < 7:
        return
    
    anomalies = detect_anomaly(sales.data)
    for a in anomalies:
        if a["severity"] == "high":
            db.table("alerts").insert({
                "user_id": user_id,
                "type": "anomaly",
                "message": f"📈 Sales {a['type'].upper()} detected on {a['date']}: Revenue was ₹{a['revenue']} ({a['pct_from_average']:+.0f}% from average)",
                "created_at": datetime.utcnow().isoformat()
            }).execute()

async def check_at_risk_customers(user_id: str):
    """Mark and alert at-risk customers."""
    db = get_supabase()
    customers = db.table("customers").select("id, name, last_purchase, segment").eq("user_id", user_id).execute()
    
    from datetime import timedelta
    now = datetime.utcnow()
    
    for c in (customers.data or []):
        if c.get("last_purchase"):
            last = datetime.fromisoformat(c["last_purchase"].replace("Z", ""))
            days_inactive = (now - last).days
            if days_inactive > 30 and c.get("segment") != "at_risk":
                db.table("customers").update({"segment": "at_risk"}).eq("id", c["id"]).execute()
                db.table("alerts").insert({
                    "user_id": user_id,
                    "type": "at_risk_customer",
                    "message": f"👤 Customer '{c['name']}' hasn't purchased in {days_inactive} days. Consider re-engagement.",
                    "created_at": datetime.utcnow().isoformat()
                }).execute()
