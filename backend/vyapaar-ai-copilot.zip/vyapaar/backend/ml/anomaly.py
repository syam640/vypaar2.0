import pandas as pd
import numpy as np
from typing import List, Dict, Any

def detect_anomaly(sales_data: List[Dict[str, Any]]) -> List[Dict]:
    """Detect sales anomalies using Z-score and rolling stats."""
    df = pd.DataFrame(sales_data)
    df['date'] = pd.to_datetime(df['timestamp']).dt.date
    daily = df.groupby('date')['total_price'].sum().reset_index()
    daily = daily.sort_values('date').reset_index(drop=True)

    if len(daily) < 7:
        return []

    # Z-score method
    mean = daily['total_price'].mean()
    std = daily['total_price'].std()
    
    if std == 0:
        return []

    daily['z_score'] = (daily['total_price'] - mean) / std
    daily['rolling_mean'] = daily['total_price'].rolling(7, min_periods=3).mean()
    daily['rolling_std'] = daily['total_price'].rolling(7, min_periods=3).std()

    anomalies = []
    for _, row in daily.iterrows():
        if abs(row['z_score']) > 2.0:
            anomaly_type = "spike" if row['z_score'] > 0 else "drop"
            pct_change = ((row['total_price'] - mean) / mean * 100) if mean > 0 else 0
            anomalies.append({
                "date": str(row['date']),
                "revenue": round(row['total_price'], 2),
                "type": anomaly_type,
                "z_score": round(row['z_score'], 2),
                "pct_from_average": round(pct_change, 1),
                "severity": "high" if abs(row['z_score']) > 3 else "medium"
            })

    return anomalies[-5:]  # Return last 5 anomalies
