import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import List, Dict, Any

def predict_demand(sales_data: List[Dict[str, Any]]) -> List[Dict]:
    """
    Use Prophet for demand forecasting.
    Falls back to moving average if Prophet fails or insufficient data.
    """
    try:
        from prophet import Prophet
        return _prophet_forecast(sales_data)
    except Exception as e:
        print(f"Prophet failed: {e}, using moving average fallback")
        return _moving_average_forecast(sales_data)

def _prophet_forecast(sales_data: List[Dict]) -> List[Dict]:
    from prophet import Prophet

    df = pd.DataFrame(sales_data)
    df['ds'] = pd.to_datetime(df['timestamp']).dt.date
    df['y'] = df['quantity'].astype(float)
    
    # Aggregate by date
    daily = df.groupby('ds')['y'].sum().reset_index()
    daily.columns = ['ds', 'y']
    daily['ds'] = pd.to_datetime(daily['ds'])

    if len(daily) < 5:
        return _moving_average_forecast(sales_data)

    model = Prophet(
        yearly_seasonality=False,
        weekly_seasonality=True,
        daily_seasonality=False,
        interval_width=0.80
    )
    model.fit(daily)

    future = model.make_future_dataframe(periods=7)
    forecast = model.predict(future)

    future_only = forecast[forecast['ds'] > daily['ds'].max()].head(7)
    
    result = []
    for _, row in future_only.iterrows():
        result.append({
            "date": row['ds'].strftime('%Y-%m-%d'),
            "predicted_qty": max(0, round(row['yhat'], 1)),
            "lower": max(0, round(row['yhat_lower'], 1)),
            "upper": round(row['yhat_upper'], 1),
            "confidence": 0.80,
            "product_id": None
        })
    return result

def _moving_average_forecast(sales_data: List[Dict]) -> List[Dict]:
    df = pd.DataFrame(sales_data)
    df['date'] = pd.to_datetime(df['timestamp']).dt.date
    daily = df.groupby('date')['quantity'].sum().reset_index()
    
    last_7 = daily['quantity'].tail(7).values
    avg = np.mean(last_7) if len(last_7) > 0 else 5
    trend = np.polyfit(range(len(last_7)), last_7, 1)[0] if len(last_7) >= 2 else 0

    result = []
    base_date = datetime.utcnow().date()
    for i in range(1, 8):
        predicted = max(0, avg + (trend * i))
        result.append({
            "date": (base_date + timedelta(days=i)).strftime('%Y-%m-%d'),
            "predicted_qty": round(predicted, 1),
            "lower": round(max(0, predicted * 0.7), 1),
            "upper": round(predicted * 1.3, 1),
            "confidence": 0.65,
            "product_id": None
        })
    return result
