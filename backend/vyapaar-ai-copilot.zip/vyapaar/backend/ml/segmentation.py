import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from datetime import datetime
from typing import List, Dict, Any

def segment_customers(customers: List[Dict], sales: List[Dict]) -> List[Dict]:
    """RFM-based customer segmentation using KMeans."""
    if not customers:
        return []

    now = datetime.utcnow()
    
    # Build RFM from DB data
    rfm_rows = []
    for c in customers:
        cid = c["id"]
        c_sales = [s for s in sales if s.get("customer_id") == cid]
        
        if c.get("last_purchase"):
            last = datetime.fromisoformat(c["last_purchase"].replace("Z", ""))
            recency = (now - last).days
        else:
            recency = 999
        
        frequency = c.get("frequency", 0) or 0
        monetary = c.get("total_spent", 0) or 0
        
        rfm_rows.append({
            "customer_id": cid,
            "name": c.get("name"),
            "recency": recency,
            "frequency": frequency,
            "monetary": monetary
        })

    df = pd.DataFrame(rfm_rows)

    if len(df) < 3:
        # Not enough for clustering — rule-based fallback
        results = []
        for _, row in df.iterrows():
            if row["frequency"] >= 5 and row["recency"] < 30:
                seg = "loyal"
            elif row["recency"] > 60:
                seg = "at_risk"
            else:
                seg = "new"
            results.append({"customer_id": row["customer_id"], "name": row["name"], "segment": seg,
                             "recency": row["recency"], "frequency": row["frequency"], "monetary": row["monetary"]})
        return results

    # KMeans clustering
    features = df[["recency", "frequency", "monetary"]].values
    scaler = StandardScaler()
    scaled = scaler.fit_transform(features)

    n_clusters = min(3, len(df))
    kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    df["cluster"] = kmeans.fit_predict(scaled)

    # Interpret clusters by centroid characteristics
    centroids = scaler.inverse_transform(kmeans.cluster_centers_)
    centroid_df = pd.DataFrame(centroids, columns=["recency", "frequency", "monetary"])

    # Label: loyal = high freq+monetary, low recency; at_risk = high recency; new = low everything
    labels = {}
    for i, row in centroid_df.iterrows():
        score = (-row["recency"] * 0.3) + (row["frequency"] * 0.4) + (row["monetary"] * 0.3)
        labels[i] = score

    sorted_clusters = sorted(labels.items(), key=lambda x: x[1])
    cluster_map = {}
    cluster_map[sorted_clusters[0][0]] = "at_risk"
    cluster_map[sorted_clusters[-1][0]] = "loyal"
    if len(sorted_clusters) > 2:
        cluster_map[sorted_clusters[1][0]] = "new"

    df["segment"] = df["cluster"].map(lambda x: cluster_map.get(x, "new"))

    return df[["customer_id", "name", "segment", "recency", "frequency", "monetary"]].to_dict("records")
