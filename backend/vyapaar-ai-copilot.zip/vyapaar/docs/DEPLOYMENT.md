# 🏪 Vyapaar AI Copilot — Deployment Guide

## ⚡ QUICK START (20 Minutes)

---

## STEP 1 — SUPABASE SETUP (3 min)

1. Go to https://supabase.com → New Project
2. Copy your **Project URL** and **Service Role Key** (Settings > API)
3. Go to SQL Editor → paste `database/schema.sql` → Run
4. Enable Auth (Email provider is default)

---

## STEP 2 — BACKEND DEPLOY ON RENDER (5 min)

1. Push backend folder to GitHub
2. Go to https://render.com → New Web Service
3. Connect your GitHub repo → select `backend/` as root
4. Set environment:
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `uvicorn main:app --host 0.0.0.0 --port 10000`
5. Add Environment Variables:
   ```
   SUPABASE_URL=https://xxxxx.supabase.co
   SUPABASE_SERVICE_KEY=eyJxxx...
   OPENAI_API_KEY=sk-xxx
   GEMINI_API_KEY=AIzaxx
   SECRET_KEY=your32charrandostring
   ```
6. Deploy → copy your Render URL (e.g. https://vyapaar.onrender.com)

---

## STEP 3 — UPDATE FRONTEND (2 min)

In `frontend/src/services/api.js`:
```js
const BASE_URL = 'https://vyapaar.onrender.com';  // Your Render URL
```

In `LoginScreen.js` and `NotificationsScreen.js`:
```js
const SUPABASE_URL = 'https://your-project.supabase.co';
const SUPABASE_ANON_KEY = 'your-anon-key';  // NOT service key — anon key
```

---

## STEP 4 — REACT NATIVE BUILD (10 min)

```bash
cd frontend
npm install
npx expo install

# Test locally:
npx expo start

# Build APK (Android):
npm install -g eas-cli
eas login
eas build --platform android --profile preview
```

For APK preview build, add to `eas.json`:
```json
{
  "build": {
    "preview": {
      "android": { "buildType": "apk" }
    }
  }
}
```

---

## 🔑 API KEYS — WHERE TO GET THEM

| Key | URL | Free Tier |
|-----|-----|-----------|
| Supabase | supabase.com | 500MB DB, 50k users |
| OpenAI | platform.openai.com | Pay-per-use |
| Gemini | aistudio.google.com | Free tier available |
| Render | render.com | Free tier (sleeps after 15min) |

---

## 📁 PROJECT STRUCTURE

```
vyapaar/
├── backend/
│   ├── main.py                 # FastAPI app entry
│   ├── requirements.txt
│   ├── .env.example
│   ├── core/
│   │   ├── config.py           # Environment variables
│   │   └── database.py         # Supabase client
│   ├── routers/
│   │   ├── billing.py          # Bill creation API
│   │   ├── dashboard.py        # Dashboard stats
│   │   ├── products.py         # Product CRUD
│   │   ├── customers.py        # Customer CRUD
│   │   ├── ml.py               # ML endpoints
│   │   ├── insights.py         # AI insights
│   │   └── ocr.py              # OCR + Voice
│   ├── ml/
│   │   ├── forecasting.py      # Prophet demand forecast
│   │   ├── segmentation.py     # KMeans RFM clustering
│   │   └── anomaly.py          # Z-score anomaly detection
│   ├── ai/
│   │   └── engine.py           # OpenAI + Gemini AI
│   └── automation/
│       ├── triggers.py         # Event-based alerts
│       └── scheduler.py        # Daily 8AM automation
│
├── frontend/
│   ├── App.js                  # Navigation setup
│   ├── package.json
│   └── src/
│       ├── services/
│       │   └── api.js          # All API calls
│       ├── store/
│       │   └── index.js        # Redux store
│       └── screens/
│           ├── LoginScreen.js
│           ├── DashboardScreen.js
│           ├── BillingScreen.js
│           ├── ProductsScreen.js
│           ├── CustomersScreen.js
│           ├── InsightsScreen.js
│           └── NotificationsScreen.js
│
└── database/
    └── schema.sql              # Full Supabase schema
```

---

## 🔄 DATA FLOW

```
User creates bill (Mobile App)
       ↓
POST /bill/create (FastAPI)
       ↓
Insert into sales table (Supabase)
       ↓
Reduce product stock
       ↓
Update customer stats (spent, frequency)
       ↓
Trigger: check stock alert → insert alert
Trigger: check anomaly → insert alert
       ↓
Daily 8AM: ML segmentation runs
           Demand forecast updates
           AI generates daily insight
       ↓
App displays alerts + insights
```

---

## 🚀 OPTIONAL ADDITIONS

1. **WhatsApp notifications** → Twilio or Meta API
2. **SMS alerts** → Twilio or MSG91
3. **Multi-user (team)** → add role column to profiles
4. **Print receipt** → Expo Print module
5. **Barcode scanner** → expo-barcode-scanner
6. **GST billing** → add gst_rate column to products
7. **Custom domain** → add on Render dashboard

---

## 🐛 TROUBLESHOOTING

- **"Not enough data"** → Add at least 5-10 sales before running ML
- **Render sleep** → Upgrade to paid plan or use Railway.app
- **OCR not working** → Install tesseract: `apt-get install tesseract-ocr`
- **Voice not working** → Requires physical device (not simulator)

---

## 💡 PRODUCTION CHECKLIST

- [ ] Set ENVIRONMENT=production in Render
- [ ] Enable Supabase Email confirmations
- [ ] Add proper error monitoring (Sentry)
- [ ] Set up database backups in Supabase
- [ ] Use Render paid plan for always-on
- [ ] Test on real Android device
- [ ] Submit to Google Play Store
